// Firebase Web App config.
// Project ID from your existing Firebase project: karthi-meka
//
// Replace the remaining placeholders with the Web App config shown in:
// Firebase Console -> Project settings -> Your apps -> Web app -> SDK setup.

export const firebaseConfig = {
  apiKey: "PASTE_API_KEY",
  authDomain: "karthi-meka.firebaseapp.com",
  projectId: "karthi-meka",
  storageBucket: "PASTE_STORAGE_BUCKET",
  messagingSenderId: "PASTE_SENDER_ID",
  appId: "PASTE_APP_ID"
};

export const FIREBASE_ENABLED =
  firebaseConfig.apiKey !== "PASTE_API_KEY" &&
  firebaseConfig.projectId === "karthi-meka";
