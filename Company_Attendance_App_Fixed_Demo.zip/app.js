// Self-contained demo build.
// This file intentionally avoids ES module imports so index.html can be opened by double-click.

const DEMO_USERS = [
  { id:"admin", password:"admin123", role:"admin", name:"Company Admin", phone:"9876543210", department:"Management", uid:"demo-admin" },
  { id:"emp001", password:"123456", role:"employee", name:"Demo Employee", phone:"9876543211", department:"Sales", uid:"demo-emp001" },
  { id:"punch01", password:"123456", role:"punch", name:"Punch Device", phone:"9876543212", department:"Attendance", uid:"demo-punch01" }
];

let employees = JSON.parse(localStorage.getItem("ca_employees") || "null") || [
  { id:"emp001", name:"Demo Employee", phone:"9876543211", department:"Sales", uid:"demo-emp001" }
];
let attendance = JSON.parse(localStorage.getItem("ca_attendance") || "[]");
let currentProfile = null;
let cameraStream = null;

const $ = id => document.getElementById(id);

function normalizeId(v){return String(v||"").trim().toLowerCase().replace(/[^a-z0-9._-]/g,"");}
function dayKey(ts=Date.now()){
  const d=new Date(ts); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}
function fmtTime(ts){return ts?new Date(ts).toLocaleTimeString("en-IN",{hour:"2-digit",minute:"2-digit"}):"—";}
function escapeHtml(v){return String(v??"").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;");}
function setMessage(id,msg,ok=false){const e=$(id); if(!e)return; e.textContent=msg||""; e.style.color=ok?"#15803d":"#b91c1c";}
function toast(msg){const e=$("toast");e.textContent=msg;e.classList.remove("hidden");setTimeout(()=>e.classList.add("hidden"),2400);}
function employeeName(id){return employees.find(e=>e.id===id)?.name||id;}
function todayRecords(id){return attendance.filter(a=>a.employeeId===id&&a.day===dayKey()).sort((a,b)=>b.createdAt-a.createdAt);}

function enterApp(){
  $("loginView").classList.add("hidden");
  $("appView").classList.remove("hidden");
  $("logoutBtn").classList.remove("hidden");
  const info={
    admin:["ADMIN","Admin Dashboard","Manage employees and view company attendance."],
    employee:["EMPLOYEE","Employee Dashboard","View your profile and attendance history."],
    punch:["PUNCH SCAN","Punch Scan","Record employee punch in and punch out."]
  }[currentProfile.role];
  $("roleEyebrow").textContent=info[0];
  $("dashboardTitle").textContent=info[1];
  $("dashboardSubtitle").textContent=info[2];
  $("userChip").textContent=`${currentProfile.name} • ${currentProfile.id}`;
  render();
}
function render(){
  ["adminDashboard","employeeDashboard","punchDashboard"].forEach(id=>$(id).classList.add("hidden"));
  $(`${currentProfile.role}Dashboard`).classList.remove("hidden");
  if(currentProfile.role==="admin")renderAdmin();
  if(currentProfile.role==="employee")renderEmployee();
  if(currentProfile.role==="punch")renderPunch();
}
function renderAdmin(){
  const today=attendance.filter(a=>a.day===dayKey());
  $("adminEmployeeCount").textContent=employees.length;
  $("adminPresentCount").textContent=new Set(today.filter(a=>a.type==="IN").map(a=>a.employeeId)).size;
  $("adminPunchCount").textContent=today.length;
  $("employeeList").innerHTML=employees.map(e=>`
    <div class="mini-item">
      <div><strong>${escapeHtml(e.id)} — ${escapeHtml(e.name)}</strong><small>${escapeHtml(e.department||"—")} • ${escapeHtml(e.phone||"")}</small></div>
      <span>${todayRecords(e.id).some(a=>a.type==="IN")?"Present":"—"}</span>
    </div>`).join("")||`<div class="empty">No employees yet.</div>`;
  $("adminAttendance").innerHTML=attendance.slice(0,100).map(attendanceCard).join("")||`<div class="empty">No attendance records yet.</div>`;
}
function renderEmployee(){
  const mine=attendance.filter(a=>a.employeeId===currentProfile.id).sort((a,b)=>b.createdAt-a.createdAt);
  const today=mine.filter(a=>a.day===dayKey());
  const hasIn=today.some(a=>a.type==="IN"), hasOut=today.some(a=>a.type==="OUT");
  $("employeeTodayStatus").textContent=hasIn?(hasOut?"Complete":"Present"):"Absent";
  $("employeeLastPunch").textContent=mine.length?fmtTime(mine[0].createdAt):"—";
  $("employeeHistoryCount").textContent=mine.length;
  $("employeeProfile").innerHTML=`<div class="mini-list">
    <div class="mini-item"><span>Employee ID</span><strong>${escapeHtml(currentProfile.id)}</strong></div>
    <div class="mini-item"><span>Name</span><strong>${escapeHtml(currentProfile.name)}</strong></div>
    <div class="mini-item"><span>Department</span><strong>${escapeHtml(currentProfile.department||"—")}</strong></div>
    <div class="mini-item"><span>Phone</span><strong>${escapeHtml(currentProfile.phone||"—")}</strong></div>
  </div>`;
  $("employeeAttendance").innerHTML=mine.slice(0,100).map(attendanceCard).join("")||`<div class="empty">No attendance records yet.</div>`;
}
function renderPunch(){}
function attendanceCard(a){
  return `<article class="booking-card"><div class="booking-top"><div>
    <strong>${escapeHtml(employeeName(a.employeeId))} (${escapeHtml(a.employeeId)})</strong>
    <div class="booking-meta">${escapeHtml(a.day)} • ${fmtTime(a.createdAt)}<br>Device: ${escapeHtml(a.deviceId||"—")}${a.note?`<br>Note: ${escapeHtml(a.note)}`:""}</div>
  </div><span class="status ${a.type==="IN"?"in":"out"}">${a.type==="IN"?"Punch In":"Punch Out"}</span></div></article>`;
}
function persist(){localStorage.setItem("ca_employees",JSON.stringify(employees));localStorage.setItem("ca_attendance",JSON.stringify(attendance));}

$("loginForm").addEventListener("submit",e=>{
  e.preventDefault();
  const id=normalizeId($("loginId").value), pw=$("loginPassword").value;
  const user=DEMO_USERS.find(u=>u.id===id&&u.password===pw);
  if(!user){setMessage("loginMessage","Wrong ID or password.");return;}
  setMessage("loginMessage","");
  currentProfile={...user};
  enterApp();
});
$("employeeForm").addEventListener("submit",e=>{
  e.preventDefault();
  const id=normalizeId($("employeeId").value);
  if(employees.some(x=>x.id===id)){setMessage("employeeMessage","Employee ID already exists.");return;}
  employees.push({id,name:$("employeeName").value.trim(),phone:$("employeePhone").value.trim(),department:$("employeeDepartment").value.trim(),uid:`demo-${id}`});
  persist();e.target.reset();render();setMessage("employeeMessage","Employee created.",true);
});
$("punchForm").addEventListener("submit",e=>{
  e.preventDefault();
  const id=normalizeId($("punchEmployeeId").value);
  if(!employees.some(x=>x.id===id)){setMessage("punchMessage","Employee ID not found.");return;}
  attendance.unshift({id:`demo-${Date.now()}`,employeeId:id,type:$("punchType").value,note:$("punchNote").value.trim(),deviceId:currentProfile.id,day:dayKey(),createdAt:Date.now()});
  persist();$("punchNote").value="";setMessage("punchMessage","Punch recorded successfully.",true);toast("Attendance recorded.");
});
$("startCameraBtn").addEventListener("click",async()=>{
  try{
    if(!navigator.mediaDevices?.getUserMedia)throw new Error("Camera API unavailable");
    if(cameraStream)cameraStream.getTracks().forEach(t=>t.stop());
    cameraStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:"user"},audio:false});
    $("camera").srcObject=cameraStream;setMessage("cameraMessage","Camera started.",true);
  }catch(e){setMessage("cameraMessage","Camera unavailable or permission denied.");}
});
$("captureBtn").addEventListener("click",()=>{
  const v=$("camera"),c=$("snapshot");
  if(!cameraStream||!v.videoWidth){setMessage("cameraMessage","Start the camera first.");return;}
  c.width=v.videoWidth;c.height=v.videoHeight;c.getContext("2d").drawImage(v,0,0);
  setMessage("cameraMessage","Frame captured. Demo build does not verify a face.",true);
});
$("logoutBtn").addEventListener("click",()=>{
  if(cameraStream)cameraStream.getTracks().forEach(t=>t.stop());
  currentProfile=null;$("appView").classList.add("hidden");$("loginView").classList.remove("hidden");$("logoutBtn").classList.add("hidden");
});
