# Firestore seed data

After enabling Authentication and Firestore, create these Auth users.

Use this convention because the app turns an ID into a pseudo-email:
- Admin: admin@karthi-meka-attendance.app
- Employee: emp001@karthi-meka-attendance.app
- Punch: punch01@karthi-meka-attendance.app

Recommended passwords for testing:
- Admin: admin123
- Employee: 123456
- Punch: 123456

Then create the following Firestore documents.

## users/{ADMIN_UID}
id: "admin"
role: "admin"
name: "Company Admin"
phone: "9876543210"
department: "Management"

## users/{EMPLOYEE_UID}
id: "emp001"
role: "employee"
name: "Demo Employee"
phone: "9876543211"
department: "Sales"

## users/{PUNCH_UID}
id: "punch01"
role: "punch"
name: "Punch Device"
phone: "9876543212"
department: "Attendance"

## employees/emp001
id: "emp001"
uid: "{EMPLOYEE_UID}"
name: "Demo Employee"
phone: "9876543211"
department: "Sales"

The IDs/UIDs above are examples. Replace UID placeholders with the actual Firebase Auth user UIDs.

## Attendance structure

Collection: attendance

Example:
{
  "employeeId": "emp001",
  "type": "IN",
  "note": "",
  "deviceId": "punch01",
  "day": "2026-09-30",
  "createdAt": 1780XXXXXXXXXX
}
