# Company Attendance App — FIXED DEMO

## Demo login now works by double-clicking `index.html`

Use:
- Admin: `admin` / `admin123`
- Employee: `emp001` / `123456`
- Punch: `punch01` / `123456`

This build is self-contained for Demo Mode and stores demo data in browser localStorage.

## Important
This fixed demo build intentionally does NOT initialize Firebase automatically, so it can be opened directly with double-click without browser ES-module/CORS problems.

For production Firebase:
- use the previous Firebase-connected source as a starting point;
- connect Firebase Authentication + Firestore through a local web server or hosting;
- keep service-account credentials off the browser.

The Firebase project ID intended for this project is `karthi-meka`.

## Test

1. Extract the ZIP.
2. Double-click `index.html`.
3. Login with one of the demo accounts.

### Test punch
Login as:
`punch01 / 123456`

Then:
Employee ID: `emp001`
Type: Punch In
Click Record Punch.

Logout and login as:
`emp001 / 123456`

You will see the attendance history.

